#ifndef _memory_
#define _memory_	

void check_pointer(void* pointer);

#endif
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<readline.h>


int main(){
    FILE *file;
    file = fopen("file","wb");
    if (file == NULL){
    	printf("error creating file\n");
    	exit;
	}

    int num_records; 
    scanf("%d ", &num_records);
    
    for(int record = 0; record < num_records; record++){
        int   id     ; scanf("%d ", &id);
        char* title  = read_line();
        char* author = read_line();
        int len_author = strlen(author);

        char bin_record[100];
        sprintf(bin_record, "%d%s|%d%s\n", id, title, len_author, author);

        // gerar linha unica com tudo junto, seguindo o seguinte formato: 
        // 10The Hunger Games|15Suzanne Collins-1
        // Criar arquivo com id e byte offset de cada um 
        // 

        printf("%ld -> %s" , strlen(bin_record), bin_record); 

        free(title);
        free(author);
    }

    int num_restored_records; 
    scanf("%d", & num_restored_records);

    return 0;
}
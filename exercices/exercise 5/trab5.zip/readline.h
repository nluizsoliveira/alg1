#ifndef _readline_
#define _readline_	

char* read_line_from_file(FILE* file);

#endif
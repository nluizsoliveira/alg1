import re
from binary_record_encoder_decoder import RecordEncoder, RecordDecoder

encode = RecordEncoder.encode
decode = RecordDecoder.decode
# índice primário 
#   id: chave
# índice secundário
#   autor: chave
#   acoplamento fraco

# 3 arquivos: 
#   1. arquivo de fato
#   2. índice primário
#   3. índice secundário 

def add(id_, title, author):
    file_ab = open("file", "ab")
    stream_size, binary_stream, pack_format = encode(int(id_), title, author)
    file_ab.write(binary_stream)
    print('Registro inserido')
    file_ab.close()
    
def remove(id_ , title , author):
    print(id_, title, author)

def search(id_, title, author):
    print(id_, title, author)

def exit(*kw):
    print('exit')

OPERATIONS = {
    'ADD': add,
    'SEARCH': remove,
    'REMOVE': search,
    'EXIT': exit,
}

def parse_input(input_):
    regex = (r"(?P<operation>\w*)?"
             r"( id='(?P<id>[^']*)')?"
             r"( titulo='(?P<title>[^']*)')?"
             r"( autor='(?P<author>[^']*)')?")
    match = re.search(regex, input_)
    return match.groupdict().values()

operation = ''
while operation != 'EXIT':
    operation, *args = parse_input(input())
    print('----------------------------------------------------------')
    OPERATIONS[operation](*args)
    

# id,user,password|id,user,password|...








